package com.capgemini.exception;

public class PasswordValidationException  extends Exception{

	private static final long serialVersionUID = 1L;

	
	public PasswordValidationException() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public PasswordValidationException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
