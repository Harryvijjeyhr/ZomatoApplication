package com.capgemini.exception;

public class NoRecordsFound  extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	

	public NoRecordsFound() {
		super();
		// TODO Auto-generated constructor stub
	}

	public NoRecordsFound(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
